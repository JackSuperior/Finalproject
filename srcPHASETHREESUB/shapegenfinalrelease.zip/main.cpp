#include <iostream>
int main() {
  std::cout << "Welcome to Shape Generator.\n";
  std::cout << "Let's start with choosing a shape.\n";
  std::string test;
using namespace std;
   int usinshape;
   int sidesquare;
   cout << "Would you rather have a:\n" << "|  Square □ (1)  |  " << "Rectangle ▭ (2)  |  " << "Triangle △ (3)  |" << "\n"; 
   cin >> usinshape;
    if (usinshape > 3) {
     cout << "You can't enter a value higher then 3, please try again.\n";
     cin >> usinshape;
   }
   if(usinshape == 1) {
     cout << "For a square, we only need one value for all four sides.\n" << "Side length: ";
     cin >> sidesquare;
    using std::cout;
    cout << "+";
    int sidesquareCOMP;
    sidesquareCOMP = sidesquare/1.5 + sidesquare;
    for (int i = 0; i < sidesquareCOMP; i++) {
        cout << "-";
    }
    cout << "+\n";
    for (int i = 0; i < sidesquareCOMP/2; i++) {
        cout << "|";
        for (int j = 0; j < sidesquareCOMP; j++) {
            cout << " ";
        }
        cout << "|\n";
    }
    cout << "+";
    for (int i = 0; i < sidesquareCOMP; i++) {
        cout << "-";
    }
    cout << "+\n";
return 0;
   }
int rectwidt;
int rectheig;
if(usinshape == 2) {
         cout << "For a rectangle, we need two values for the width and height.\n" << "Width: ";
     cin >> rectwidt;
     cout << "Height: ";
     cin >> rectheig;
    cout << "+";
      int rectwidtCOMP;
    rectwidtCOMP = rectwidt/1.5 + rectwidt;
    for (int i = 0; i < rectwidtCOMP; i++) {
        cout << "-";
    }
    cout << "+\n";
    for (int i = 0; i < rectheig - 2; i++) {
        cout << "|";
        for (int j = 0; j < rectwidtCOMP; j++){
            cout << " ";
        }
        cout << "|\n";
    }
    cout << "+";
    for (int i = 0; i < rectwidtCOMP; i++) {
        cout << "-";
    }
    cout << "+\n";
    return 0;
   }
   int usintrishape;
   if(usinshape == 3) {
   cout << "You could either do a Right Triangle (1) or an Equilateral Triangle (2)\n";
   cin >> usintrishape;
  if (usintrishape > 2) {
     cout << "You can't enter a value higher then 2, please try again.\n";
     cin >> usintrishape;
     return 0;
   }
   int triRrows;
   if (usintrishape == 1) {
     cout << "For a right triangle, you need one value for the Rows.\n" << "Rows: ";
     cin >> triRrows;
    int i, k;
    for (k = 1; k <= triRrows; k++) {
        for (i = 1; i <= k; i++)
            cout << '*';
        cout << endl;
    }
    getchar();
    getchar();
    return 0;    
}
   }
   int trirows;
   if (usintrishape == 2) {
     cout << "For an equilateral triangle, we only need one value for the amount of rows.\n" << "Rows: ";
     cin >> trirows;
     int i, j, k;
    for (k = 1; k <= trirows; k++) {
       for(j = 1; j <= trirows-k; j++)
            cout << ' ';
       for (i = 1; i <= 2*k-1; i++)
            cout << "△";
       cout << endl;
    }
    return 0;
}
   }