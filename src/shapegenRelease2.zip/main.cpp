#include <iostream>
int main() {
  std::cout << "Welcome to Shape Generator.\n";
  std::cout << "Let's start with choosing a shape.\n";
  std::string test;
using namespace std;
   int usinshape;
   int sidesquare;
   int rectwidt;
   int rectheig;
   cout << "Would you rather have a:\n" << "|  Square □ (1)  |  " << "Rectangle ▭ (2)  |  " << "Triangle △ (3)  |" << "\n"; 
   cin >> usinshape;
   if(usinshape == 1) {
     cout << "For a square, we only need one value for all four sides.\n" << "Side length: ";
     cin >> sidesquare;
    using std::cout;
    cout << "+";
    int sidesquareCOMP;
    sidesquareCOMP = sidesquare/1.5 + sidesquare;
    for (int i = 0; i < sidesquareCOMP; i++) {
        cout << "-";
    }
    cout << "+\n";
    for (int i = 0; i < sidesquareCOMP/2; i++) {
        cout << "|";
        for (int j = 0; j < sidesquareCOMP; j++) {
            cout << " ";
        }
        cout << "|\n";
    }
    cout << "+";
    for (int i = 0; i < sidesquareCOMP; i++) {
        cout << "-";
    }
    cout << "+\n";
return 0;
   }
if(usinshape == 2) {
         cout << "For a rectangle, we need two values for the width and height.\n" << "Width: ";
     cin >> rectwidt;
     cout << "Height: ";
     cin >> rectheig;
    cout << "+";
      int rectwidtCOMP;
    rectwidtCOMP = rectwidt/1.5 + rectwidt;
    for (int i = 0; i < rectwidtCOMP; i++) {
        cout << "-";
    }
    cout << "+\n";
    for (int i = 0; i < rectheig - 2; i++) {
        cout << "|";
        for (int j = 0; j < rectwidtCOMP; j++){
            cout << " ";
        }
        cout << "|\n";
    }
    cout << "+";
    for (int i = 0; i < rectwidtCOMP; i++) {
        cout << "-";
    }
    cout << "+\n";
    return 0;
   }
}
